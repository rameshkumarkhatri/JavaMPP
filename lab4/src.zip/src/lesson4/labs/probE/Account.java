package lesson4.labs.probE;

public abstract class Account {

    abstract String getAccountID();
    abstract double getBalance();
    abstract double computeUpdatedBalance();
}
